# projetVB
Prototype de système de gestion ABONNET

* login?
* validation code client
* gestion des locations
* état des équipements
* programmation de site
* gestion des appels téléphonique
* formations
* rapports et statistiques
